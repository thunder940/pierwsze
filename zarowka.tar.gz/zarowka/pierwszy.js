var addon = require('./build/Release/zarowka');

addon.zarowka();

