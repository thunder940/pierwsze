var addon = require('./build/Release/przycisk');

console.log("nic sie nie stalo");
console.log(addon.przycisk());
addon.przycisk();

